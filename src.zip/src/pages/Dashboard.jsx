import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import StatCard from '../components/layout/common/StatCard';
import ResidentFormModal from '../components/residents/ResidentFormModal';
import DocumentFormModal from '../components/documents/DocumentFormModal';
import IncidentFormModal from '../components/incidents/IncidentFormModal';
import { useDocuments } from '../hooks/useDocuments';
import { useIncidents } from '../hooks/useIncidents';
import { useResidents } from '../hooks/useResidents';
import {
  Users, FileText, AlertCircle, Calendar, Clock, Flag,
  Megaphone, Bell, ArrowRight, UserPlus, FilePlus,
  MapPin, Eye, ChevronRight, Loader
} from 'lucide-react';

const Dashboard = () => {
  const navigate = useNavigate();
  const { documents, loading: docsLoading, loadDocuments, stats: docStats, loadStatistics: loadDocStats } = useDocuments();
  const { incidents, loadIncidents, stats: incidentStats, loadStatistics: loadIncidentStats } = useIncidents();
  const { stats: residentStats, loadStatistics: loadResidentStats } = useResidents();

  const [pageLoading, setPageLoading] = useState(true);
  const [activeDocTab, setActiveDocTab] = useState('All');
  const [showAddResidentModal, setShowAddResidentModal] = useState(false);
  const [showIssueDocModal, setShowIssueDocModal] = useState(false);
  const [showIncidentModal, setShowIncidentModal] = useState(false);

  useEffect(() => {
    const init = async () => {
      await Promise.all([
        loadDocuments({ limit: 6 }),
        loadIncidents(5, true),
        loadResidentStats(),
      ]);
      setPageLoading(false);
      loadDocStats();
      loadIncidentStats();
    };
    init();
  }, []);

  const docTabs = ['All', 'Pending', 'Approved', 'Processing', 'Denied'];

  const handleTabChange = async (tab) => {
    setActiveDocTab(tab);
    if (tab === 'All') await loadDocuments({ limit: 6 });
    else await loadDocuments({ status: tab, limit: 6 });
  };

  const tabCount = (tab) => {
    if (tab === 'All') return docStats?.total || documents.length;
    const key = tab.toLowerCase();
    return docStats?.[key] ?? documents.filter(d => d.status === tab).length;
  };

  const filteredDocs = documents.slice(0, 6);

  const formatTime = (ts) => {
    if (!ts) return 'Just now';
    try {
      const d = ts.toDate ? ts.toDate() : new Date(ts);
      const diff = Math.floor((Date.now() - d.getTime()) / 1000);
      if (diff < 60) return `${diff}s ago`;
      if (diff < 3600) return `${Math.floor(diff / 60)} mins ago`;
      if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
      return d.toLocaleDateString();
    } catch { return 'Recently'; }
  };

  const docStatusStyle = (s) => {
    const m = { Approved: { bg: '#ecfdf5', color: '#065f46' }, Denied: { bg: '#fef2f2', color: '#991b1b' }, Processing: { bg: '#eff6ff', color: '#1e40af' } };
    return m[s] || { bg: '#fffbeb', color: '#92400e' };
  };

  const quickActions = [
    { label: 'Add New Resident', icon: UserPlus, color: '#eff6ff', textColor: '#1e40af', action: () => setShowAddResidentModal(true) },
    { label: 'Issue Document',   icon: FilePlus,  color: '#f0fdf4', textColor: '#166534', action: () => setShowIssueDocModal(true) },
    { label: 'Report Incident',  icon: Flag,      color: '#fffbeb', textColor: '#92400e', action: () => setShowIncidentModal(true) },
    { label: 'Create Announcement', icon: Megaphone, color: '#f5f3ff', textColor: '#6b21a8', action: () => navigate('/announcements') },
    { label: 'Send Alert',       icon: Bell,      color: '#fef2f2', textColor: '#991b1b', action: () => navigate('/drrm') },
  ];

  const activeIncidentsList = incidents.filter(i => i.status !== 'Resolved').slice(0, 3);

  const incidentSeverity = (i) => {
    if (i.severity === 'Urgent' || i.priority === 'High') return 'urgent';
    if (i.status === 'Under Mediation') return 'mediation';
    return 'open';
  };

  const incidentStyles = {
    urgent:    { border: '#ef4444', bg: '#fef2f2', badge: { bg: '#fee2e2', color: '#991b1b' } },
    open:      { border: '#f59e0b', bg: '#fffbeb', badge: { bg: '#fef3c7', color: '#92400e' } },
    mediation: { border: '#3b82f6', bg: '#eff6ff', badge: { bg: '#dbeafe', color: '#1e40af' } },
  };

  const upcomingEvents = [
    { month: 'DEC', day: '15', title: 'Community Clean-up Drive', location: 'All Puroks • 7:00 AM', participants: 234, color: '#3b82f6' },
    { month: 'DEC', day: '20', title: 'Christmas Party',          location: 'Barangay Hall • 5:30 PM', participants: 150, color: '#8b5cf6' },
    { month: 'JAN', day: '5',  title: 'Health Seminar',           location: 'Health Center • 9:00 AM', participants: 80,  color: '#10b981' },
  ];

  const statsCards = [
    { label: 'Total Residents',    value: residentStats?.total?.toLocaleString() || '—', badge: residentStats ? `${residentStats.male||0}M / ${residentStats.female||0}F` : 'Loading...', badgeColor: 'badge-success', icon: Users,       iconBg: 'icon-bg-primary',   nav: '/residents' },
    { label: 'Pending Documents',  value: docStats?.pending?.toString() || documents.filter(d=>d.status==='Pending').length.toString() || '—', badge: 'Needs attention', badgeColor: 'badge-warning', icon: FileText,    iconBg: 'icon-bg-warning',   nav: '/documents' },
    { label: 'Active Incidents',   value: incidentStats?.open?.toString() || incidents.filter(i=>i.status==='Open').length.toString() || '—', badge: 'Requires action', badgeColor: 'badge-error',   icon: AlertCircle, iconBg: 'icon-bg-error',     nav: '/incidents' },
    { label: 'Upcoming Events',    value: '12',                                          badge: 'This month',       badgeColor: 'badge-gray',    icon: Calendar,    iconBg: 'icon-bg-secondary', nav: '/events' },
  ];

  if (pageLoading) return (
    <div className="loading-container" style={{ height: '60vh' }}>
      <Loader size={32} style={{ color: '#3b82f6', animation: 'spin 0.8s linear infinite' }} />
    </div>
  );

  // Shared card style used across both columns
  const cardStyle = {
    background: '#fff',
    borderRadius: '14px',
    border: '1px solid #f0f4f8',
    boxShadow: '0 1px 4px rgba(0,0,0,0.06)',
    overflow: 'hidden',
  };

  const cardHeaderStyle = {
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '18px 20px',
    borderBottom: '1px solid #f8fafc',
  };

  const cardTitleStyle = {
    fontSize: '15px', fontWeight: 700, color: '#0f172a',
    fontFamily: "'Plus Jakarta Sans', sans-serif",
  };

  const linkBtnStyle = {
    display: 'flex', alignItems: 'center', gap: '4px',
    background: 'none', border: 'none', cursor: 'pointer',
    color: '#3b82f6', fontSize: '13px', fontWeight: 600,
    fontFamily: "'Inter', sans-serif",
    padding: '4px 0',
    transition: 'color 0.15s',
  };

  return (
    <div className="page-container">

      {/* ── Header ── */}
      <div className="page-header">
        <div className="page-header-content">
          <h1 className="page-title">Dashboard Overview</h1>
          <p className="page-subtitle">Welcome back! Here's what's happening in your barangay today.</p>
        </div>
      </div>

      {/* ── Stats ── */}
      <div className="stats-grid">
        {statsCards.map((s, i) => (
          <StatCard key={i} title={s.label} value={s.value} icon={s.icon}
            iconBg={s.iconBg} badge={s.badge} badgeColor={s.badgeColor}
            onClick={() => navigate(s.nav)} />
        ))}
      </div>

      {/* ── Main Row: Documents + Quick Actions ── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: '20px', marginBottom: '20px' }}>

        {/* Recent Documents */}
        <div style={cardStyle}>
          <div style={cardHeaderStyle}>
            <span style={cardTitleStyle}>Recent Document Requests</span>
            <button style={linkBtnStyle} onClick={() => navigate('/documents')}>
              View All <ArrowRight size={14} />
            </button>
          </div>

          {/* Tabs */}
          <div style={{ display: 'flex', gap: '6px', padding: '14px 20px 12px', borderBottom: '1px solid #f8fafc', overflowX: 'auto' }}>
            {docTabs.map(tab => {
              const count = tabCount(tab);
              const active = activeDocTab === tab;
              return (
                <button key={tab} onClick={() => handleTabChange(tab)} style={{
                  display: 'flex', alignItems: 'center', gap: '5px',
                  padding: '5px 12px',
                  borderRadius: '20px', border: 'none',
                  fontSize: '13px', fontWeight: 600,
                  cursor: 'pointer', whiteSpace: 'nowrap',
                  fontFamily: "'Inter', sans-serif",
                  background: active ? '#3b82f6' : '#f8fafc',
                  color: active ? '#fff' : '#64748b',
                  boxShadow: active ? '0 2px 8px rgba(59,130,246,0.28)' : 'none',
                  transition: 'all 0.15s',
                }}>
                  {tab}
                  {tab !== 'All' && count > 0 && (
                    <span style={{
                      padding: '1px 6px', borderRadius: '10px', fontSize: '11px',
                      background: active ? 'rgba(255,255,255,0.25)' : '#e8ecf0',
                      color: active ? '#fff' : '#94a3b8',
                    }}>{count}</span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Doc List */}
          <div style={{ padding: '8px 0' }}>
            {docsLoading ? (
              [1,2,3].map(i => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '14px', padding: '12px 20px' }}>
                  <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: '#f1f5f9', flexShrink: 0 }} />
                  <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '6px' }}>
                    <div style={{ height: '13px', width: '50%', borderRadius: '6px', background: '#f1f5f9' }} />
                    <div style={{ height: '11px', width: '30%', borderRadius: '6px', background: '#f8fafc' }} />
                  </div>
                  <div style={{ width: '64px', height: '24px', borderRadius: '8px', background: '#f1f5f9' }} />
                </div>
              ))
            ) : filteredDocs.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '36px', color: '#94a3b8' }}>
                <FileText size={36} style={{ margin: '0 auto 10px', display: 'block', opacity: 0.3 }} />
                <p style={{ fontSize: '14px', fontWeight: 500 }}>No {activeDocTab === 'All' ? '' : activeDocTab} requests yet</p>
              </div>
            ) : filteredDocs.map(doc => {
              const st = docStatusStyle(doc.status);
              return (
                <div key={doc.id} style={{ display: 'flex', alignItems: 'center', gap: '14px', padding: '11px 20px', cursor: 'pointer', transition: 'background 0.12s' }}
                  onMouseEnter={e => e.currentTarget.style.background = '#fafbfc'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                  onClick={() => navigate('/documents')}>
                  <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: st.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <FileText size={18} color={st.color} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', margin: 0 }}>
                      {doc.documentType || 'Document Request'}
                    </p>
                    <p style={{ fontSize: '12px', color: '#94a3b8', margin: '2px 0 0' }}>
                      {doc.requester?.name || 'N/A'} • {formatTime(doc.systemInfo?.requestDate || doc.systemInfo?.createdAt)}
                    </p>
                  </div>
                  <span style={{ padding: '4px 10px', borderRadius: '20px', fontSize: '11px', fontWeight: 700, background: st.bg, color: st.color, whiteSpace: 'nowrap' }}>
                    {doc.status || 'Pending'}
                  </span>
                  <Eye size={15} color="#cbd5e1" />
                </div>
              );
            })}
          </div>
        </div>

        {/* Quick Actions */}
        <div style={cardStyle}>
          <div style={cardHeaderStyle}>
            <span style={cardTitleStyle}>Quick Actions</span>
          </div>
          <div style={{ padding: '12px' }}>
            {quickActions.map((action, i) => {
              const Icon = action.icon;
              return (
                <button key={i} onClick={action.action} style={{
                  display: 'flex', alignItems: 'center', gap: '12px',
                  width: '100%', padding: '12px 14px', marginBottom: '6px',
                  border: 'none', borderRadius: '10px', cursor: 'pointer',
                  background: action.color, color: action.textColor,
                  fontSize: '14px', fontWeight: 600,
                  fontFamily: "'Inter', sans-serif",
                  textAlign: 'left', transition: 'filter 0.15s, transform 0.12s',
                }}
                onMouseEnter={e => { e.currentTarget.style.filter = 'brightness(0.96)'; e.currentTarget.style.transform = 'translateX(2px)'; }}
                onMouseLeave={e => { e.currentTarget.style.filter = 'none'; e.currentTarget.style.transform = 'none'; }}>
                  <Icon size={18} strokeWidth={2} style={{ flexShrink: 0 }} />
                  <span style={{ flex: 1 }}>{action.label}</span>
                  <ChevronRight size={15} style={{ opacity: 0.4 }} />
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ── Bottom Row: Incidents + Events ── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>

        {/* Active Incidents */}
        <div style={cardStyle}>
          <div style={cardHeaderStyle}>
            <span style={cardTitleStyle}>Active Incidents</span>
            <button style={linkBtnStyle} onClick={() => navigate('/incidents')}>
              View All <ArrowRight size={14} />
            </button>
          </div>
          <div style={{ padding: '12px' }}>
            {activeIncidentsList.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '28px', color: '#94a3b8' }}>
                <AlertCircle size={34} style={{ margin: '0 auto 10px', display: 'block', opacity: 0.3 }} />
                <p style={{ fontSize: '14px', fontWeight: 500 }}>No active incidents</p>
                <p style={{ fontSize: '13px', marginTop: '4px' }}>All clear!</p>
              </div>
            ) : activeIncidentsList.map((incident, i) => {
              const sev = incidentSeverity(incident);
              const sStyle = incidentStyles[sev];
              return (
                <div key={incident.id || i} style={{
                  padding: '14px 16px', marginBottom: '8px',
                  borderRadius: '10px', borderLeft: `3px solid ${sStyle.border}`,
                  background: sStyle.bg,
                  cursor: 'pointer', transition: 'transform 0.12s',
                }}
                onMouseEnter={e => e.currentTarget.style.transform = 'translateX(3px)'}
                onMouseLeave={e => e.currentTarget.style.transform = 'none'}
                onClick={() => navigate('/incidents')}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px' }}>
                    <p style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a', margin: 0 }}>
                      {incident.title || incident.category || 'Incident'}
                    </p>
                    <span style={{ padding: '3px 10px', borderRadius: '20px', fontSize: '11px', fontWeight: 700, background: sStyle.badge.bg, color: sStyle.badge.color, whiteSpace: 'nowrap' }}>
                      {sev.toUpperCase()}
                    </span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '14px', marginTop: '6px' }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '12px', color: '#64748b' }}>
                      <MapPin size={12} />{incident.location || incident.complainant?.purok || 'Unknown'}
                    </span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '12px', color: '#64748b' }}>
                      <Clock size={12} />{formatTime(incident.systemInfo?.createdAt)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Upcoming Events */}
        <div style={cardStyle}>
          <div style={cardHeaderStyle}>
            <span style={cardTitleStyle}>Upcoming Events</span>
            <button style={linkBtnStyle} onClick={() => navigate('/events')}>
              View Calendar <ArrowRight size={14} />
            </button>
          </div>
          <div style={{ padding: '12px' }}>
            {upcomingEvents.map((event, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'flex-start', gap: '14px',
                padding: '12px', marginBottom: '6px', borderRadius: '10px',
                cursor: 'pointer', transition: 'background 0.12s',
              }}
              onMouseEnter={e => e.currentTarget.style.background = '#f8fafc'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
              onClick={() => navigate('/events')}>
                <div style={{
                  width: '52px', height: '52px', borderRadius: '12px',
                  background: event.color, color: '#fff',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0,
                }}>
                  <span style={{ fontSize: '10px', fontWeight: 700, opacity: 0.85, letterSpacing: '0.05em' }}>{event.month}</span>
                  <span style={{ fontSize: '22px', fontWeight: 800, lineHeight: 1 }}>{event.day}</span>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a', margin: '0 0 3px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{event.title}</p>
                  <p style={{ fontSize: '12px', color: '#64748b', margin: '0 0 3px' }}>{event.location}</p>
                  <p style={{ fontSize: '11px', color: '#94a3b8', margin: 0 }}>{event.participants} registered</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Modals ── */}
      <ResidentFormModal isOpen={showAddResidentModal} onClose={() => setShowAddResidentModal(false)}
        onSuccess={() => { setShowAddResidentModal(false); navigate('/residents'); }} />
      <DocumentFormModal isOpen={showIssueDocModal} onClose={() => setShowIssueDocModal(false)}
        onSuccess={() => { setShowIssueDocModal(false); loadDocuments({ limit: 6 }); loadDocStats(); }} />
      <IncidentFormModal isOpen={showIncidentModal} onClose={() => setShowIncidentModal(false)}
        onSuccess={() => { setShowIncidentModal(false); loadIncidents(5, true); loadIncidentStats(); }} />
    </div>
  );
};

export default Dashboard;