// src/components/documents/DocumentFormModal.jsx
import React, { useState, useEffect } from 'react';
import { X, Save, Loader, FileText, User, ClipboardList, CreditCard, ChevronRight, ChevronLeft, CheckCircle } from 'lucide-react';
import { useDocuments } from '../../hooks/useDocuments';
import { DOCUMENT_TYPES } from '../../services/documentsService';

const PAYMENT_METHODS = ['Cash', 'GCash', 'PayMaya', 'Online Banking', 'Free of Charge'];

const STEPS = [
  { id: 'requester', label: 'Requester',  icon: User         },
  { id: 'document',  label: 'Document',   icon: FileText     },
  { id: 'payment',   label: 'Payment',    icon: CreditCard   },
];

const Field = ({ label, required, error, hint, children }) => (
  <div className="form-group">
    <label className="form-label">
      {label}{required && <span style={{ color: '#ef4444', marginLeft: 2 }}>*</span>}
    </label>
    {children}
    {hint && !error && <span style={{ fontSize: 12, color: '#94a3b8', marginTop: 4, display: 'block' }}>{hint}</span>}
    {error && <span className="form-error">{error}</span>}
  </div>
);

const DocumentFormModal = ({ isOpen, onClose, document: docProp = null, onSuccess }) => {
  const { create, update, loading } = useDocuments();
  const isEdit = !!docProp;

  const documentTypeOptions = Object.entries(DOCUMENT_TYPES || {}).map(([key, val]) => ({
    key, name: val.name, fee: val.fee || 0,
  }));

  const [step, setStep]   = useState(0);
  const [errors, setErrors] = useState({});

  const empty = {
    requesterName: '', contactNumber: '', requesterAddress: '',
    residentId: '', documentTypeId: '', purpose: '',
    additionalDetails: '', paymentMethod: 'Cash', paymentReference: '',
  };

  const [form, setForm] = useState(empty);

  useEffect(() => {
    if (isOpen) {
      if (docProp) {
        const matchedKey = Object.keys(DOCUMENT_TYPES || {}).find(k => DOCUMENT_TYPES[k].name === docProp.documentType) || '';
        setForm({
          requesterName:     docProp.requester?.name || '',
          contactNumber:     docProp.requester?.contactNumber || '',
          requesterAddress:  docProp.requester?.address || '',
          residentId:        docProp.requester?.residentId || '',
          documentTypeId:    matchedKey,
          purpose:           docProp.purpose || '',
          additionalDetails: docProp.additionalDetails || '',
          paymentMethod:     docProp.payment?.method || 'Cash',
          paymentReference:  docProp.payment?.reference || '',
        });
      } else {
        setForm(empty);
      }
      setStep(0);
      setErrors({});
    }
  }, [isOpen, docProp]);

  if (!isOpen) return null;

  const set = (field, val) => {
    setForm(p => ({ ...p, [field]: val }));
    if (errors[field]) setErrors(p => ({ ...p, [field]: '' }));
  };

  const selectedDocType = documentTypeOptions.find(d => d.key === form.documentTypeId);
  const fee = selectedDocType?.fee || 0;
  const isFree = form.paymentMethod === 'Free of Charge' || fee === 0;

  const validateStep = (s) => {
    const e = {};
    if (s === 0) {
      if (!form.requesterName.trim()) e.requesterName = 'Name is required';
      if (!form.contactNumber.trim()) {
        e.contactNumber = 'Contact number is required';
      } else if (!/^(09|\+639)\d{9}$/.test(form.contactNumber.replace(/\s|-/g, ''))) {
        e.contactNumber = 'Invalid format — use 09XX XXX XXXX';
      }
    }
    if (s === 1) {
      if (!form.documentTypeId) e.documentTypeId = 'Document type is required';
      if (!form.purpose.trim())  e.purpose        = 'Purpose is required';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const next = () => { if (validateStep(step)) setStep(s => s + 1); };
  const back = () => setStep(s => s - 1);

  const handleSubmit = async () => {
    if (!validateStep(step)) return;
    const payload = {
      documentTypeId:   form.documentTypeId,
      requesterName:    form.requesterName,
      contactNumber:    form.contactNumber,
      requesterAddress: form.requesterAddress,
      residentId:       form.residentId || null,
      purpose:          form.purpose,
      additionalDetails:form.additionalDetails,
      paymentMethod:    form.paymentMethod,
      paymentReference: form.paymentReference,
      fee,
    };
    const result = isEdit ? await update(docProp.id, payload) : await create(payload);
    if (result.success) { onSuccess?.(); onClose(); }
    else setErrors({ submit: result.error });
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: '#fff', borderRadius: 20, width: '100%', maxWidth: 620,
          maxHeight: '92vh', display: 'flex', flexDirection: 'column',
          boxShadow: '0 24px 64px rgba(15,23,42,0.18)', overflow: 'hidden',
        }}
      >
        {/* Header */}
        <div style={{ padding: '20px 28px 0', flexShrink: 0 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 42, height: 42, borderRadius: 12, background: '#eff6ff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <FileText size={20} color="#3b82f6" />
              </div>
              <div>
                <h2 style={{ fontSize: 17, fontWeight: 700, color: '#0f172a', margin: 0 }}>
                  {isEdit ? 'Edit Document Request' : 'New Document Request'}
                </h2>
                <p style={{ fontSize: 13, color: '#64748b', margin: 0 }}>Issue a barangay document</p>
              </div>
            </div>
            <button className="btn-icon" onClick={onClose}><X size={20} /></button>
          </div>

          {/* Steps */}
          <div style={{ display: 'flex', gap: 0 }}>
            {STEPS.map((s, i) => {
              const active = i === step;
              const done   = i < step;
              const Icon   = s.icon;
              return (
                <button key={s.id} onClick={() => done && setStep(i)}
                  style={{
                    flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                    padding: '10px 8px', background: 'none', border: 'none',
                    cursor: done ? 'pointer' : 'default',
                    borderBottom: active ? '2.5px solid #3b82f6' : done ? '2.5px solid #10b981' : '2.5px solid #e2e8f0',
                  }}>
                  <div style={{
                    width: 22, height: 22, borderRadius: '50%', fontSize: 11, fontWeight: 700,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: active ? '#3b82f6' : done ? '#10b981' : '#e2e8f0',
                    color: active || done ? '#fff' : '#94a3b8',
                  }}>
                    {done ? '✓' : i + 1}
                  </div>
                  <span style={{ fontSize: 13, fontWeight: active ? 600 : 400, color: active ? '#1e40af' : done ? '#065f46' : '#64748b' }}>
                    {s.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '24px 28px' }}>
          {errors.submit && (
            <div style={{ background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 10, padding: '12px 16px', marginBottom: 20, fontSize: 13, color: '#dc2626' }}>
              {errors.submit}
            </div>
          )}

          {/* STEP 0 — Requester */}
          {step === 0 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <Field label="Full Name" required error={errors.requesterName}>
                <input className={`form-input ${errors.requesterName ? 'error' : ''}`}
                  value={form.requesterName} onChange={e => set('requesterName', e.target.value)}
                  placeholder="Juan Dela Cruz" />
              </Field>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                <Field label="Contact Number" required error={errors.contactNumber}>
                  <input className={`form-input ${errors.contactNumber ? 'error' : ''}`}
                    value={form.contactNumber} onChange={e => set('contactNumber', e.target.value)}
                    placeholder="09XX XXX XXXX" />
                </Field>
                <Field label="Resident ID" hint="If registered in the system">
                  <input className="form-input" value={form.residentId}
                    onChange={e => set('residentId', e.target.value)}
                    placeholder="Leave blank if unknown" />
                </Field>
              </div>
              <Field label="Address" hint="Street / Purok / Barangay">
                <input className="form-input" value={form.requesterAddress}
                  onChange={e => set('requesterAddress', e.target.value)}
                  placeholder="e.g. Purok 3, Brgy. Example" />
              </Field>
            </div>
          )}

          {/* STEP 1 — Document */}
          {step === 1 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <Field label="Document Type" required error={errors.documentTypeId}>
                <select className={`form-select ${errors.documentTypeId ? 'error' : ''}`}
                  value={form.documentTypeId} onChange={e => set('documentTypeId', e.target.value)}>
                  <option value="">— Select document type —</option>
                  {documentTypeOptions.map(d => (
                    <option key={d.key} value={d.key}>{d.name}{d.fee > 0 ? ` (₱${d.fee})` : ' (Free)'}</option>
                  ))}
                </select>
              </Field>

              {selectedDocType && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 16px', background: '#eff6ff', borderRadius: 10, border: '1px solid #bfdbfe' }}>
                  <FileText size={16} color="#3b82f6" />
                  <div>
                    <p style={{ margin: 0, fontWeight: 600, fontSize: 14, color: '#1e40af' }}>{selectedDocType.name}</p>
                    <p style={{ margin: 0, fontSize: 13, color: '#3b82f6' }}>
                      Fee: {fee > 0 ? `₱${fee.toFixed(2)}` : 'Free'}
                    </p>
                  </div>
                </div>
              )}

              <Field label="Purpose" required error={errors.purpose}>
                <input className={`form-input ${errors.purpose ? 'error' : ''}`}
                  value={form.purpose} onChange={e => set('purpose', e.target.value)}
                  placeholder="e.g. Employment, Loan Application, School Requirement" />
              </Field>

              <Field label="Additional Details / Notes" hint="Optional">
                <textarea className="form-textarea" rows={3} value={form.additionalDetails}
                  onChange={e => set('additionalDetails', e.target.value)}
                  placeholder="Any special instructions or details to include on the document..." />
              </Field>
            </div>
          )}

          {/* STEP 2 — Payment */}
          {step === 2 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {/* Fee summary */}
              <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 14, padding: '18px 20px' }}>
                <p style={{ fontSize: 12, fontWeight: 600, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '.05em', margin: '0 0 12px' }}>Order Summary</p>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingBottom: 12, borderBottom: '1px solid #e2e8f0', marginBottom: 12 }}>
                  <span style={{ fontSize: 14, color: '#374151' }}>{selectedDocType?.name || 'Document'}</span>
                  <span style={{ fontSize: 14, fontWeight: 600, color: '#0f172a' }}>₱{fee.toFixed(2)}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: 15, fontWeight: 700, color: '#0f172a' }}>Total Due</span>
                  <span style={{ fontSize: 18, fontWeight: 800, color: fee > 0 ? '#1e40af' : '#065f46' }}>
                    {fee > 0 ? `₱${fee.toFixed(2)}` : 'FREE'}
                  </span>
                </div>
              </div>

              {/* Payment method */}
              <div>
                <label className="form-label">Payment Method</label>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                  {PAYMENT_METHODS.map(m => (
                    <button key={m} onClick={() => set('paymentMethod', m)} type="button"
                      style={{
                        padding: '10px 14px', borderRadius: 10, cursor: 'pointer',
                        border: form.paymentMethod === m ? '2px solid #3b82f6' : '1.5px solid #e2e8f0',
                        background: form.paymentMethod === m ? '#eff6ff' : '#fff',
                        color: form.paymentMethod === m ? '#1e40af' : '#374151',
                        fontWeight: form.paymentMethod === m ? 600 : 400,
                        fontSize: 13, textAlign: 'left',
                        display: 'flex', alignItems: 'center', gap: 8,
                      }}>
                      {form.paymentMethod === m && <CheckCircle size={14} color="#3b82f6" />}
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reference number for digital payments */}
              {!isFree && form.paymentMethod !== 'Cash' && (
                <Field label="Reference / Transaction Number" hint="For GCash/PayMaya/Online Banking payments">
                  <input className="form-input" value={form.paymentReference}
                    onChange={e => set('paymentReference', e.target.value)}
                    placeholder="e.g. GC-123456789" />
                </Field>
              )}

              {/* Final summary */}
              <div style={{ padding: '14px 18px', background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 12 }}>
                <p style={{ fontSize: 13, fontWeight: 700, color: '#166534', margin: '0 0 8px' }}>Request Summary</p>
                <div style={{ fontSize: 13, color: '#374151', display: 'flex', flexDirection: 'column', gap: 4 }}>
                  <span><strong>Requester:</strong> {form.requesterName}</span>
                  <span><strong>Document:</strong> {selectedDocType?.name || '—'}</span>
                  <span><strong>Purpose:</strong> {form.purpose}</span>
                  <span><strong>Payment:</strong> {form.paymentMethod}{form.paymentReference ? ` (Ref: ${form.paymentReference})` : ''}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ padding: '16px 28px', borderTop: '1px solid #f1f5f9', display: 'flex', justifyContent: 'space-between', background: '#fafafa', flexShrink: 0 }}>
          <button className="btn btn-secondary btn-md" onClick={step === 0 ? onClose : back} disabled={loading} type="button">
            {step === 0 ? 'Cancel' : <><ChevronLeft size={16} />Back</>}
          </button>
          {step < STEPS.length - 1 ? (
            <button className="btn btn-primary btn-md" onClick={next} type="button">
              Continue <ChevronRight size={16} />
            </button>
          ) : (
            <button className="btn btn-primary btn-md" onClick={handleSubmit} disabled={loading} type="button">
              {loading
                ? <><Loader size={15} className="animate-spin" />Submitting...</>
                : <><Save size={15} />{isEdit ? 'Update Request' : 'Submit Request'}</>}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default DocumentFormModal;